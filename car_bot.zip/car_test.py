# Import Dependencies
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import os
import time
from bs4 import BeautifulSoup
import re
import pandas as pd
import requests

# Telegram Bot Configuration
TELEGRAM_TOKEN = ''
TELEGRAM_CHAT_ID = ''

def send_telegram_message(message):
    """Send a notification via Telegram."""
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {'chat_id': TELEGRAM_CHAT_ID, 'text': message, 'parse_mode': 'HTML'}
    response = requests.post(url, data=payload)
    if response.status_code == 200:
        print(f"Message sent: {message}")
    else:
        print(f"Failed to send message: {response.text}")

# Configure Chromedriver
chrome_install = ChromeDriverManager().install()
folder = os.path.dirname(chrome_install)
chromedriver_path = os.path.join(folder, "chromedriver")

# Initialize Chrome WebDriver
browser = webdriver.Chrome(
    service=Service(chromedriver_path),
)

# Set up search URL
city = ""
product = ""
url = f'https://www.facebook.com/marketplace/{city}/vehicles?query={product}&radius=150'

# Visit Facebook Marketplace
browser.get(url)

# Handle pop-ups and cookies
try:
    close_button = browser.find_element(By.XPATH, '//div[@aria-label="Close" and @role="button"]')
    close_button.click()
    print("Close button clicked!")
except:
    print("Could not find or click the close button!")
    pass

# Scroll down to load more listings
try:
    last_height = browser.execute_script("return document.body.scrollHeight")
    while True:
        browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(4)
        new_height = browser.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break
        last_height = new_height
except Exception as e:
    print(f"An error occurred during scrolling: {e}")

# Parse the HTML with BeautifulSoup
html = browser.page_source
browser.close()
soup = BeautifulSoup(html, 'html.parser')

# Extract all links from listings
links = soup.find_all('a')
car_data = []
for link in links:
    text = ' '.join(link.stripped_strings)
    if product.lower() in text.lower():
        car_data.append({
            'text': text,
            'url': link.get('href'),
        })

# Extract price and sort listings
numeric_pattern = re.compile(r'\d[\d,.]*')
processed_data = []
for car in car_data:
    match = numeric_pattern.search(car['text'])
    if match:
        price = float(match.group().replace(',', '').replace('$', ''))
        processed_data.append({
            'price': price,
            'text': car['text'],
            'url': f"https://www.facebook.com{car['url']}" if car['url'] else None
        })

# Sort data by price
processed_data = sorted(processed_data, key=lambda x: x['price'])

# Get the cheapest car
if processed_data:
    cheapest = processed_data[0]
    message = f"Cheapest ... in ...:\n\nTitle: {cheapest['text']}\nPrice: ${cheapest['price']}\nURL: {cheapest['url']}"
    send_telegram_message(message)
else:
    send_telegram_message("")
