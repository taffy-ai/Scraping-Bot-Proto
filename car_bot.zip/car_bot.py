# Import Dependencies
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import os
import time
from bs4 import BeautifulSoup
import re
import pandas as pd
import requests

# Telegram Bot Configuration
TELEGRAM_TOKEN = ''
TELEGRAM_CHAT_ID = ''

def send_telegram_message(message):
    """Send a notification via Telegram."""
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {'chat_id': TELEGRAM_CHAT_ID, 'text': message, 'parse_mode': 'HTML'}
    response = requests.post(url, data=payload)
    if response.status_code == 200:
        print(f"Message sent: {message}")
    else:
        print(f"Failed to send message: {response.text}")

# Configure Chromedriver
chrome_install = ChromeDriverManager().install()
folder = os.path.dirname(chrome_install)
chromedriver_path = os.path.join(folder, "chromedriver")

# Initialize Chrome WebDriver
browser = webdriver.Chrome(
    service=Service(chromedriver_path),
)

# Setup search parameters
city = ""
product = ""
min_price = 0
max_price = 4500
days_listed = 7  # Searching in the last 7 days

# Set up base URL
url = f'https://www.facebook.com/marketplace/{city}/vehicles?query={product}&minPrice={min_price}&maxPrice={max_price}&daysSinceListed={days_listed}&radius=150'

# Visit the website
browser.get(url)

# Handle pop-ups and cookies
try:
    decline_button = browser.find_element(By.XPATH, '//div[@aria-label="Close" and @role="button"]')
    decline_button.click()
    print("Decline optional cookies button clicked!")
except:
    print("Could not find or click the optional cookies button!")
    pass

try:
    close_button = browser.find_element(By.XPATH, '//div[@aria-label="Close" and @role="button"]')
    close_button.click()
    print("Close button clicked!")
except:
    print("Could not find or click the close button!")
    pass

# Scroll down to load all results
try:
    last_height = browser.execute_script("return document.body.scrollHeight")
    while True:
        browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(4)
        new_height = browser.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break
        last_height = new_height
        print("scrolled")
except Exception as e:
    print(f"An error occurred: {e}")

# Retrieve the HTML and close the browser
html = browser.page_source
browser.close()

# Parse the HTML with BeautifulSoup
soup = BeautifulSoup(html, 'html.parser')

# Find and filter listings
links = soup.find_all('a')
car_links = [link for link in links if product.lower() in link.text.lower() and city.lower() in link.text.lower()]

# Extract product data
car_data = []
for car_link in car_links:
    url = car_link.get('href')
    text = '\n'.join(car_link.stripped_strings)
    car_data.append({'text': text, 'url': url})

# Extract relevant details
extracted_data = []
for item in car_data:
    lines = item['text'].split('\n')
    numeric_pattern = re.compile(r'\d[\d,.]*')
    for line in lines:
        match = numeric_pattern.search(line)
        if match:
            price_str = match.group()
            price = float(price_str.replace(',', ''))
            break
    else:
        price = None

    if price and price <= max_price:
        title = lines[-2]
        location = lines[-1]
        extracted_data.append({
            'title': title,
            'price': price,
            'location': location,
            'url': re.sub(r'\?.*', '', item['url'])
        })

# Convert extracted data into a Pandas DataFrame
items_df = pd.DataFrame(extracted_data)

# Filter by mileage, year, and transmission
items_df['mileage'] = items_df['title'].apply(lambda x: int(re.search(r'(\d[\d,]*\s?km)', x).group(1).replace('km', '').replace(',', '')) if 'km' in x else 0)
items_df['year'] = items_df['title'].apply(lambda x: int(re.search(r'\b(20\d{2}|19\d{2})\b', x).group()) if re.search(r'\b(20\d{2}|19\d{2})\b', x) else 0)
filtered_df = items_df[(items_df['mileage'] <= 185000) & (items_df['year'] >= 2011) & (items_df['title'].str.contains("Automatic", case=False))]

# Get the 10 cheapest entries
cheapest_10 = filtered_df.sort_values(by='price').head(10)

# Create the Telegram message
message = ""
for index, row in cheapest_10.iterrows():
    message += f"Title: {row['title']}\nPrice: ${row['price']}\nLocation: {row['location']}\nMileage: {row['mileage']} km\nYear: {row['year']}\nURL: {row['url']}\n\n"

# Send the message to Telegram
send_telegram_message(message)
